
public interface UserService {
    User getUserById(Long id);
    User createUser(User user);
    // Other service methods can be added here
}
    