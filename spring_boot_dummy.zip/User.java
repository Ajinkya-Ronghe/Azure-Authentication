
public class User {
    private Long id;
    private String name;
    private String email;

    // Constructors, getters and setters for id, name, and email go here
}
    